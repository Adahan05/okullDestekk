//
//  ODEVC.swift
//  OKUL DESTEK
//
//  Created by Adahan on 19.11.2017.
//  Copyright © 2017 Okul Destek. All rights reserved.
//



import UIKit


// Class lar buraya :


class ODEVC: UIViewController , UIPickerViewDelegate , UIPickerViewDataSource , UIImagePickerControllerDelegate , UINavigationControllerDelegate {

    // StoryBoard TextField'lerimiz
    
    // Ders Yazma Text Field
    

    @IBOutlet weak var DERSTextField: UITextField!
    
    
    // Tarih Yazma Text Field
    @IBOutlet weak var TARİHTextField: UITextField!
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        
    }
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var odevText: UITextView!
    
    
    
    
    
    // Dersler
    let datePicker = UIDatePicker()

    let Dersler = [String](arrayLiteral: "Türkçe", "Teknoloji ve Tasarım", "T.C: İnkılap Tarihi", "Trafik Güvenliği", "Müzik", "Matematik","Felsefe", "Fen Bilimleri", "Hayat Bilgisi", "Ingilizce", "Bioloji", "Beden Eğitim","Fizik", "Kimya", "Italyanca", "Almanca", "Fransızca", "Din Kültür","Rehberlik", "Insan Hakları", "Görsel Sanatlar", "Çizim", "Dil ve Anlatım", "Geometri","Türk Edebiyat", "Tarih", "Coğrafya", "Seçmeli Ders", "Sosyoloji")
    
    // Açılınca Yapılan Işlemler
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //ODEV EKLEME
        

        
        
        imageView.isUserInteractionEnabled = true
        let gestureRecongnizer = UITapGestureRecognizer(target: self, action: #selector(ODEVC.selectImage))
        imageView.addGestureRecognizer(gestureRecongnizer)
        
        
        
        
        
        
        //ODEV EKLEME
        
        createDatePicker()
        datePicker.locale = Locale(identifier: "tr");
        
       // Picker
        
        let secici = UIPickerView()
        secici.delegate = self
        
        // Picker den TextField'a Veri Aktarımı
        DERSTextField.inputView = secici
    }
    
    
    
    
    // resim seçme
    @objc func selectImage() {
        
      let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true, completion: nil)
        
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info : [String : Any]) {
        imageView.image = info[UIImagePickerControllerEditedImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
    }
    
    
    /* Gereksiz Func
     
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    } */
    
    // Picker View Func ları
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return Dersler.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return Dersler[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        DERSTextField.text = Dersler[row]
        self.view.endEditing(false)
    }
    
    func createDatePicker() {
        
        // format for picker
        datePicker.datePickerMode = .date
        
        // toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        // Çıkış Buton
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: false)
        
        TARİHTextField.inputAccessoryView = toolbar
        
        // Date Picker Text Yazısını çekme
        TARİHTextField.inputView = datePicker
        
        
    }
    
    @objc func donePressed() {
        
        self.view.endEditing(true)
        // Zaman Formatı
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .none
        dateFormatter.locale = Locale(identifier: "tr")
        TARİHTextField.text = dateFormatter.string(from: datePicker.date)
        
    }
    
}


